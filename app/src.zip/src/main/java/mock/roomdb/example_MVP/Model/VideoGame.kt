package mock.roomdb.example_MVP.Model

/**
 * Created by BalaKrishnan on 26-02-2018.
 */

data class VideoGame(val name: String, val publisher: String, var reviewScore: Int)