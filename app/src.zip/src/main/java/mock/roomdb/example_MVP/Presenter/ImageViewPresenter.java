package mock.roomdb.example_MVP.Presenter;

/**
 * Created by BalaKrishnan on 23-02-2018.
 */

public interface ImageViewPresenter {

   void newText(String n, String r);
}
